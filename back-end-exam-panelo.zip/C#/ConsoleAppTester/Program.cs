﻿using System;
using System.Collections.Generic;
using System.Linq;
using RefactorMe;
using RefactorMe.DontRefactor;
using RefactorMe.DontRefactor.Models;

namespace ConsoleAppTester
{
    class Program
    {
        static void Main(string[] args)
        {
            // Method 3: Only 1 query to the repositories, price conversion done afterwards. 
            // Uses System.Reflection to dynamically queries the repositories.
            // Loops thru the defined currencies to push the price-converted products.
            Console.WriteLine("***Method 3: Only 1 query to the repositories, price conversion done afterwards.***");
            Console.WriteLine("***Uses System.Reflection to dynamically queries the repositories.***");
            Console.WriteLine("***Loops thru the defined currencies to push the price-converted products.***");

            ProductDataConsolidator3 data3 = new ProductDataConsolidator3();
            List<ProductInfo> products3 = data3.Get();
            ListProducts(products3);
            Console.WriteLine();

            // Method 1: Each currency listing queries the repositories.
            Console.WriteLine("***Method 1: Each currency listing queries the repositories.***");
            ListProducts(CurrencyEnum.NZD);
            ListProducts(CurrencyEnum.USD);
            ListProducts(CurrencyEnum.Euro);


            // Method 2: Only 1 query to the repositories, price conversion done afterwards.
            Console.WriteLine("***Method 2: Only 1 query to the repositories, price conversion done afterwards.***");
            ProductDataConsolidator2 data = new ProductDataConsolidator2();
            List<ProductInfo> products = data.Get(RepEnum.ALL);

            data.ConvertPrice(CurrencyEnum.NZD);
            ListProducts(CurrencyEnum.NZD, products);

            data.ConvertPrice(CurrencyEnum.USD);
            ListProducts(CurrencyEnum.USD, products);

            data.ConvertPrice(CurrencyEnum.Euro);
            ListProducts(CurrencyEnum.Euro, products);

            Console.WriteLine("Press any key to close window.");
            Console.ReadLine();
        }

        static void ListProducts(CurrencyEnum currency)
        {
            ProductDataConsolidator2 data = new ProductDataConsolidator2(currency);
            List<ProductInfo> products = data.Get(RepEnum.ALL);

            ListProducts(currency, products);
        }

        static void ListProducts(CurrencyEnum currency, List<ProductInfo> products)
        {
            Console.WriteLine(currency);
            products.ForEach(p =>
            {
                Console.WriteLine(String.Concat(p.Name.PadRight(50), " ",
                    String.Format("{0:0.00}", p.Price).PadLeft(15), "     ",
                    p.Type));
            });
            Console.WriteLine();
        }

        static void ListProducts(List<ProductInfo> products)
        {
            Console.WriteLine();
            products.ForEach(p =>
            {
                Console.WriteLine(String.Concat(p.Name.PadRight(50), " ",
                    String.Format("{0:0.00}", p.Price).PadLeft(15), " ",
                    p.Currency.ToString().PadRight(5), "   ",
                    p.Type));
            });
            
        }


    }
}
