﻿Method 1: Each currency listing queries the repositories.
Method 2: Only 1 query to the repositories, price conversion done afterwards.

Source files for Methods 1 and 2 are in sub-folder Method12.

Method 3: Only 1 query to the repositories, price conversion done afterwards. 
          Uses System.Reflection to dynamically queries the repositories.
          Loops thru the defined currencies to push the price-converted products.

Source files for Method 3 are in sub-folder Method3.

Source files common to all methods are in sub-folder Common.

I added a console application project to test all methods.