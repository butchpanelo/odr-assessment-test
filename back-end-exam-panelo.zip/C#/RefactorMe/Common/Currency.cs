﻿using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe
{
    public enum CurrencyEnum
    {
        NZD = 1,
        USD,
        Euro
    }

    public static class Currency
    {
        public static double GetFactor(CurrencyEnum currency)
        {
            switch (currency)
            {
                case CurrencyEnum.Euro:
                    return 0.67;
                case CurrencyEnum.USD:
                    return 0.76;
                case CurrencyEnum.NZD:
                default:
                    return 1.0;
            }
        }
    }

    public class ProductInfo : Product
    {
        public CurrencyEnum Currency { get; set; }
        public double LocalPrice { get; set; }
    }
}


