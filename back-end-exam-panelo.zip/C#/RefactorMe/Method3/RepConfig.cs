﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe
{
    public class RepConfig
    {
        private const string AssemblyName = "RefactorMe.DontRefactor.Data.Implementation";
        private readonly string[] repInfo = {
            "LawnmowerRepository,Lawnmower",
            "PhoneCaseRepository,Phone Case",
            "TShirtRepository,T-Shirt"
        };

        private string[] _repClassNames;

        public RepConfig()
        {
            SetClassNames();
        }

        public string[] RepClassNames
        {
            get
            {
                return _repClassNames;
            }
        }

        public string ProductType(int index)
        {
            return repInfo[index].Split(',')[1];
        }

        public string ProductType(string className)
        {
            int searchIndex = Array.IndexOf(RepClassNames, className);
            return (searchIndex >= 0 ? ProductType(searchIndex) : String.Empty);
        }

        private void SetClassNames()
        {
            List<string> c = new List<string>();
            foreach (string s in repInfo)
            {
                c.Add(AssemblyName + "." + s.Split(',')[0]);
            }
            _repClassNames = c.ToArray();
        }
    }
}
