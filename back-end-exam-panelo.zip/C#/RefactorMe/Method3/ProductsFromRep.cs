﻿using RefactorMe.DontRefactor.Data.Implementation;
using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace RefactorMe
{
    class ProductsFromRep: IProductsFromRep
    {
        public ProductsFromRep()
        {
            
        }
      
        public List<ProductInfo> GetProductsFromRepository()
        {
            List<ProductInfo> ps = new List<ProductInfo>();
            try
            {
                RepConfig repConfig = new RepConfig();

                repConfig.RepClassNames.ToList().ForEach(c =>
                {
                    object repInstance = Util.GetInstance(c);
                    
                    var rep = (IQueryable)repInstance.GetType().GetMethod("GetAll").Invoke(repInstance, null);
                    
                    foreach (var r in rep)
                    {
                        Guid id = (Guid)r.GetType().GetProperty("Id").GetValue(r);
                        string name = (string)r.GetType().GetProperty("Name").GetValue(r);
                        double price = (double)r.GetType().GetProperty("Price").GetValue(r);
                        string ptype = repConfig.ProductType(c);

                        ps.Add(new ProductInfo { 
                            Id = id,
                            Name = name,
                            Price = price,
                            LocalPrice = price,
                            Type = ptype
                        });
                    }
                });
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ps;
        }

    }

   
}
        

       

      
    

