﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe
{
    public static class Util
    {
        public static object GetInstance(string className)
        {
            Type type = Type.GetType(className);
            if (type != null)
            {
                return Activator.CreateInstance(type);
            }
            foreach(var a in AppDomain.CurrentDomain.GetAssemblies())
            {
                type = a.GetType(className);
                if(type!=null)
                {
                    return Activator.CreateInstance(type);
                }
            }
            return null;
        }

        
       
    }

}

