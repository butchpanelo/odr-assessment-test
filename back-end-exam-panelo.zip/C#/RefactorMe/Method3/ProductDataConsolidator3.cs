﻿using RefactorMe.DontRefactor.Data.Implementation;
using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe
{
    public class ProductDataConsolidator3: IProductDataConsolidator3
    {
        public ProductDataConsolidator3()
        {
            
        }

        public List<ProductInfo> Get()
        {
            List<ProductInfo> products = null; 
          
            var curr = Enum.GetValues(typeof(CurrencyEnum));
            foreach(CurrencyEnum c in curr)
            {
                if(products==null)
                {
                    products = new List<ProductInfo>();
                }
                var p = new ProductsFromRep();
                var currP = p.GetProductsFromRepository();
                ConvertPrice(currP, c);
                products.AddRange(currP);
            }
            return products;
        }

        private void ConvertPrice(List<ProductInfo> products, CurrencyEnum currency)
        {
            foreach (var p in products)
            {
                p.Price = p.LocalPrice * Currency.GetFactor(currency);
                p.Currency = currency;
            }
        }
    }

  }
