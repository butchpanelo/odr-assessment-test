﻿using RefactorMe.DontRefactor.Data.Implementation;
using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe
{
    public enum RepEnum
    {
        ALL = 1,
        LAWNMOWER,
        PHONECASE,
        TSHIRT,
    }

    public abstract class ProductsFromRepBase
    {
        private List<Product> _products;
        public ProductsFromRepBase()
        {
            _products = new List<Product>();
        }
    }
}
        

       

      
    

