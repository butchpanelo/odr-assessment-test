﻿using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe
{
    interface IProductDataConsolidator2
    {
        List<ProductInfo> Get(RepEnum rep);
    }
}
