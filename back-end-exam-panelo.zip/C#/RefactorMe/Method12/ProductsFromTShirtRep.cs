﻿using RefactorMe.DontRefactor.Data.Implementation;
using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe
{
    class ProductsFromTShirtRep: ProductsFromRepBase, IProductsFromRep
    {
        const string PRODUCT_TYPE = "T-Shirt";

        public ProductsFromTShirtRep() {


        }
        

        public List<ProductInfo> GetProductsFromRepository()
        {
            var rep = new PhoneCaseRepository().GetAll();

            List<ProductInfo> ps = (from a in rep
                                select new ProductInfo { Id = a.Id, Name = a.Name, Price = a.Price, LocalPrice = a.Price, Type = PRODUCT_TYPE })
                                        .ToList();
            return ps;
        }
    }
}
        

       

      
    

