﻿using RefactorMe.DontRefactor.Data.Implementation;
using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe
{
    public class ProductDataConsolidator2: IProductDataConsolidator2
    {
        public List<ProductInfo> products;
        CurrencyEnum currency;
        bool hasCurrency;

        public ProductDataConsolidator2()
        {
            this.hasCurrency = false;
        }

        public ProductDataConsolidator2(CurrencyEnum currency)
        {
            this.currency = currency;
            this.hasCurrency = true;
        }

        public List<ProductInfo> Get(RepEnum rep)
        {
            products = new List<ProductInfo>();

            if (rep == RepEnum.ALL || rep == RepEnum.LAWNMOWER) { 
                var l = new ProductsFromLawnmowerRep();
                products.AddRange(l.GetProductsFromRepository());
            }

            if (rep == RepEnum.ALL || rep == RepEnum.PHONECASE)
            {
                var p = new ProductsFromPhoneCaseRep();
                products.AddRange(p.GetProductsFromRepository());
            }

            if (rep == RepEnum.ALL || rep == RepEnum.TSHIRT)
            {
                var t = new ProductsFromTShirtRep();
                products.AddRange(t.GetProductsFromRepository());
            }
            
            if(this.hasCurrency)
            {
                this.ConvertPrice(this.currency);
            }

            return products;
        }
    }

    public static class ProductDataConsolidator2Extension
    {
        public static void ConvertPrice(this ProductDataConsolidator2 data, CurrencyEnum currency)
        {
            foreach (var p in data.products)
            {
                p.Price = p.LocalPrice * Currency.GetFactor(currency);
                p.Currency = currency;
            }
        }
    }
}
