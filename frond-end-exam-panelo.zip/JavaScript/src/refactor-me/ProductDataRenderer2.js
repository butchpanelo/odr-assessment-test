﻿const gCurrencyFactor = {
	NZD: 1.0, USD: 0.76, Euro: 0.67
};
const gPlaceHolder = {
	NZD: "nzdProducts", USD: "usdProducts", Euro: "euProducts"
};

function ProductDataRenderer() {
	
}

ProductDataRenderer.prototype.render = function () {

	var te = new t(document.getElementById("productTable").innerHTML);
	var oProducts;

	this.template = te;
	
	for (var c in gCurrencyFactor) {
		if (oProducts==null) {
			oProducts = this.getProducts();
			this.products = oProducts;
		}
		//else {
			convertPrice(gCurrencyFactor[c]);
        //}
		this.renderTemplate(c, gPlaceHolder[c]);
	}
	
	function convertPrice(factor) {
		oProducts.forEach(function (p) {
			p.price = (p.localprice * factor).toFixed(2);
		});
    }
}

ProductDataRenderer.prototype.getProducts = function () {
	return ProductDataConsolidator.get();
}

ProductDataRenderer.prototype.renderTemplate = function (c, el, p) {
	try {
		var n = this.template.render({
			currencyName: c,
			products: this.products
		});

		document.getElementById(el).innerHTML = n;
	}
	catch (e) {
		console.log("Error in renderTemplate.");
    }
}
