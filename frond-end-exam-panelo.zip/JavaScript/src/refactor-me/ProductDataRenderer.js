﻿function ProductDataRenderer() {
}

ProductDataRenderer.prototype.render = function () {
	var template = new t(document.getElementById("productTable").innerHTML);

	var n = template.render({
		currencyName: "NZD",
		products: ProductDataConsolidator.get()
	});

	var u = template.render({
		currencyName: "USD",
		products: ProductDataConsolidator.getInUSDollars()
	});

	var e = template.render({
		currencyName: "Euro",
		products: ProductDataConsolidator.getInEuros()
	});

	document.getElementById("nzdProducts").innerHTML = n;
	document.getElementById("usdProducts").innerHTML = u;
	document.getElementById("euProducts").innerHTML = e;
}