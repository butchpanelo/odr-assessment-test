//'use strict';
const gCurrencyFactor = {
	NZD: 1.0, USD: 0.76, Euro: 0.67
};

// Define the `refactorApp` module
var refactorApp = angular.module('refactorApp', [])

	.controller('CurrencyListController', function CurrencyListController($scope) {
		$scope.currencyList = {};

		for (var c in gCurrencyFactor) {
			$scope.currencyList[c] = { name: c };
		}
	})

	.controller('ProductListController', ['$scope', function ProductListController($scope) {
		var oProducts;

		$scope.getProducts = function (key) {
			if (oProducts == null) {
				oProducts = ProductDataConsolidator.get();
			}
			
			var cloneP = convertPrice(gCurrencyFactor[key]);
			var productList = { products: cloneP };

			return productList.products;
		}

		function convertPrice(factor) {
			var cloneP = [].concat(oProducts);
			cloneP.forEach(function (p) {
				p.price = (p.localprice * factor).toFixed(2);
			});
			return cloneP;
		}
	}]);

	

