﻿const repMapping = {
	'Lawnmower': LawnmowerRepository,
	'Phone Case': PhoneCaseRepository,
	'T-Shirt': TShirtRepository
};

function ProductDataConsolidator() {
}

ProductDataConsolidator.get = function () {
	var products = [];
	
	for (var c in repMapping) {
		var rep = new repMapping[c]().getAll();

		rep.forEach(function (r) {
			products.push({
				id: r.id,
				name: r.name,
				price: r.price.toFixed(2),
				localprice: r.price.toFixed(2),
				type: c
			});
		});
	}
	return products;
}
